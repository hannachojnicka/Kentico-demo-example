SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_GiftCardCouponCode](
	[GiftCardCouponCodeID] [int] IDENTITY(1,1) NOT NULL,
	[GiftCardCouponCodeCode] [nvarchar](200) NOT NULL,
	[GiftCardCouponCodeRemainingValue] [decimal](18, 9) NOT NULL,
	[GiftCardCouponCodeGiftCardID] [int] NOT NULL,
	[GiftCardCouponCodeGuid] [uniqueidentifier] NOT NULL,
	[GiftCardCouponCodeLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_COM_GiftCardCouponCode] PRIMARY KEY CLUSTERED 
(
	[GiftCardCouponCodeID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_COM_GiftCardCouponCodeGiftCardID] ON [dbo].[COM_GiftCardCouponCode]
(
	[GiftCardCouponCodeGiftCardID] ASC
)
GO
ALTER TABLE [dbo].[COM_GiftCardCouponCode] ADD  CONSTRAINT [DEFAULT_COM_GiftCardCouponCode_GiftCardCouponCodeCode]  DEFAULT (N'') FOR [GiftCardCouponCodeCode]
GO
ALTER TABLE [dbo].[COM_GiftCardCouponCode] ADD  CONSTRAINT [DEFAULT_COM_GiftCardCouponCode_GiftCardCouponCodeRemainingValue]  DEFAULT ((0)) FOR [GiftCardCouponCodeRemainingValue]
GO
ALTER TABLE [dbo].[COM_GiftCardCouponCode] ADD  CONSTRAINT [DEFAULT_COM_GiftCardCouponCode_GiftCardCouponCodeGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [GiftCardCouponCodeGuid]
GO
ALTER TABLE [dbo].[COM_GiftCardCouponCode] ADD  CONSTRAINT [DEFAULT_COM_GiftCardCouponCode_GiftCardCouponCodeLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [GiftCardCouponCodeLastModified]
GO
ALTER TABLE [dbo].[COM_GiftCardCouponCode]  WITH CHECK ADD  CONSTRAINT [FK_COM_GiftCardCouponCode_GiftCardCouponCodeGiftCardID_COM_GiftCard] FOREIGN KEY([GiftCardCouponCodeGiftCardID])
REFERENCES [dbo].[COM_GiftCard] ([GiftCardID])
GO
ALTER TABLE [dbo].[COM_GiftCardCouponCode] CHECK CONSTRAINT [FK_COM_GiftCardCouponCode_GiftCardCouponCodeGiftCardID_COM_GiftCard]
GO
